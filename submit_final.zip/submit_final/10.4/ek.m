function [c, ceq] = ek(z)
   global N mx
   
   alpha=0.2;
   beta=20;
   lamda_t=2*pi/3;

   for k=1:N
    lamda_k = z(1 + (k-1)*mx);
    e_k   = z(5 + (k-1)*mx);
    c(k) = alpha * exp(-beta*(lamda_k - lamda_t)^2) - e_k;
   end 
   ceq = [];
end